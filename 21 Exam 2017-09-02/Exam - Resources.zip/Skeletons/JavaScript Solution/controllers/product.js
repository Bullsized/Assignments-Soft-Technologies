const Product = require('../models/Product');

module.exports = {
	index: (req, res) => {
        //TODO: Implement me ...
    	},
	createGet: (req, res) => {
        //TODO: Implement me ...
	},
	createPost: (req, res) => {
	//TODO: Implement me ...
	},
	editGet: (req, res) => {
        //TODO: Implement me ...
	},
	editPost: (req, res) => {
        //TODO: Implement me ...
	}
};