<?php

/* base.html.twig */
class __TwigTemplate_93e2499d03c6402ea1e3906495568257ed0120721f7f5badb0e11600e82927c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2a4cff84121150010e9fe78a2bbaba29c46d647479a4f0e07651cc2074a82be1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2a4cff84121150010e9fe78a2bbaba29c46d647479a4f0e07651cc2074a82be1->enter($__internal_2a4cff84121150010e9fe78a2bbaba29c46d647479a4f0e07651cc2074a82be1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_f647bcd81e7de2ad15ab50ebe1a45ca63c0b34a322964edb755585617cf87951 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f647bcd81e7de2ad15ab50ebe1a45ca63c0b34a322964edb755585617cf87951->enter($__internal_f647bcd81e7de2ad15ab50ebe1a45ca63c0b34a322964edb755585617cf87951_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 17
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 20
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "</body>
</html>
";
        
        $__internal_2a4cff84121150010e9fe78a2bbaba29c46d647479a4f0e07651cc2074a82be1->leave($__internal_2a4cff84121150010e9fe78a2bbaba29c46d647479a4f0e07651cc2074a82be1_prof);

        
        $__internal_f647bcd81e7de2ad15ab50ebe1a45ca63c0b34a322964edb755585617cf87951->leave($__internal_f647bcd81e7de2ad15ab50ebe1a45ca63c0b34a322964edb755585617cf87951_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_4f65504665444bbcd14977621687a4dcf34f8e0f6f83691915e1c81bbe08e669 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4f65504665444bbcd14977621687a4dcf34f8e0f6f83691915e1c81bbe08e669->enter($__internal_4f65504665444bbcd14977621687a4dcf34f8e0f6f83691915e1c81bbe08e669_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_aeabbc171541fbcf873401832171c142810162357b04f69469739182f9289f43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aeabbc171541fbcf873401832171c142810162357b04f69469739182f9289f43->enter($__internal_aeabbc171541fbcf873401832171c142810162357b04f69469739182f9289f43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Shopping List";
        
        $__internal_aeabbc171541fbcf873401832171c142810162357b04f69469739182f9289f43->leave($__internal_aeabbc171541fbcf873401832171c142810162357b04f69469739182f9289f43_prof);

        
        $__internal_4f65504665444bbcd14977621687a4dcf34f8e0f6f83691915e1c81bbe08e669->leave($__internal_4f65504665444bbcd14977621687a4dcf34f8e0f6f83691915e1c81bbe08e669_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_85e9e66daddf8b381af94e5256f04a7e1d94047eb0753e52c39ca0009c972bfb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_85e9e66daddf8b381af94e5256f04a7e1d94047eb0753e52c39ca0009c972bfb->enter($__internal_85e9e66daddf8b381af94e5256f04a7e1d94047eb0753e52c39ca0009c972bfb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_b0112029ce344a7a81e37fd79249d0d94391e582d1a84850af6557bdde2fc5d9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b0112029ce344a7a81e37fd79249d0d94391e582d1a84850af6557bdde2fc5d9->enter($__internal_b0112029ce344a7a81e37fd79249d0d94391e582d1a84850af6557bdde2fc5d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        ";
        // line 14
        echo "        ";
        // line 15
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_b0112029ce344a7a81e37fd79249d0d94391e582d1a84850af6557bdde2fc5d9->leave($__internal_b0112029ce344a7a81e37fd79249d0d94391e582d1a84850af6557bdde2fc5d9_prof);

        
        $__internal_85e9e66daddf8b381af94e5256f04a7e1d94047eb0753e52c39ca0009c972bfb->leave($__internal_85e9e66daddf8b381af94e5256f04a7e1d94047eb0753e52c39ca0009c972bfb_prof);

    }

    // line 20
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_5bfbc873f28c4409500e4ff12721c231ba2fdb1ded2ca0edfb5fd43ab927febf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5bfbc873f28c4409500e4ff12721c231ba2fdb1ded2ca0edfb5fd43ab927febf->enter($__internal_5bfbc873f28c4409500e4ff12721c231ba2fdb1ded2ca0edfb5fd43ab927febf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_5895a45cd37548b59d9eef7acd4f3900b1b725e386abcad2e33d8e68e2867eb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5895a45cd37548b59d9eef7acd4f3900b1b725e386abcad2e33d8e68e2867eb4->enter($__internal_5895a45cd37548b59d9eef7acd4f3900b1b725e386abcad2e33d8e68e2867eb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_5895a45cd37548b59d9eef7acd4f3900b1b725e386abcad2e33d8e68e2867eb4->leave($__internal_5895a45cd37548b59d9eef7acd4f3900b1b725e386abcad2e33d8e68e2867eb4_prof);

        
        $__internal_5bfbc873f28c4409500e4ff12721c231ba2fdb1ded2ca0edfb5fd43ab927febf->leave($__internal_5bfbc873f28c4409500e4ff12721c231ba2fdb1ded2ca0edfb5fd43ab927febf_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_22d77a748e247b3b0e404b9ad5ad2b4195a7b8ee44cc08f145afd51c5ad93b21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22d77a748e247b3b0e404b9ad5ad2b4195a7b8ee44cc08f145afd51c5ad93b21->enter($__internal_22d77a748e247b3b0e404b9ad5ad2b4195a7b8ee44cc08f145afd51c5ad93b21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5035579be8ab6fe33a4394757360c056a465c940c5965209f41135437c087ba2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5035579be8ab6fe33a4394757360c056a465c940c5965209f41135437c087ba2->enter($__internal_5035579be8ab6fe33a4394757360c056a465c940c5965209f41135437c087ba2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 22
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_5035579be8ab6fe33a4394757360c056a465c940c5965209f41135437c087ba2->leave($__internal_5035579be8ab6fe33a4394757360c056a465c940c5965209f41135437c087ba2_prof);

        
        $__internal_22d77a748e247b3b0e404b9ad5ad2b4195a7b8ee44cc08f145afd51c5ad93b21->leave($__internal_22d77a748e247b3b0e404b9ad5ad2b4195a7b8ee44cc08f145afd51c5ad93b21_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_87e2a9bde9c654e9a564b2548ad06acdd342d34cbd8745aea467eeaaa09ad2ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87e2a9bde9c654e9a564b2548ad06acdd342d34cbd8745aea467eeaaa09ad2ef->enter($__internal_87e2a9bde9c654e9a564b2548ad06acdd342d34cbd8745aea467eeaaa09ad2ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_6764bb215c167be6999caab397d820aa61c440b2d4725182f27b8225c08052ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6764bb215c167be6999caab397d820aa61c440b2d4725182f27b8225c08052ea->enter($__internal_6764bb215c167be6999caab397d820aa61c440b2d4725182f27b8225c08052ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_6764bb215c167be6999caab397d820aa61c440b2d4725182f27b8225c08052ea->leave($__internal_6764bb215c167be6999caab397d820aa61c440b2d4725182f27b8225c08052ea_prof);

        
        $__internal_87e2a9bde9c654e9a564b2548ad06acdd342d34cbd8745aea467eeaaa09ad2ef->leave($__internal_87e2a9bde9c654e9a564b2548ad06acdd342d34cbd8745aea467eeaaa09ad2ef_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 22,  129 => 21,  112 => 20,  99 => 15,  97 => 14,  95 => 13,  86 => 12,  68 => 11,  56 => 24,  54 => 21,  50 => 20,  43 => 17,  41 => 12,  37 => 11,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Shopping List{% endblock %}</title>
    {% block stylesheets %}
        {#<link rel=\"stylesheet\" href=\"{{ asset('css/reset-style.css') }}\">;#}
        {#<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">#}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
