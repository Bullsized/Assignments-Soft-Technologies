<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_38a6c797aab9659831372987100a40392803c422a7b2171a144e8b5467094f9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cecf06831c0d6dcede596bd4c3e4ab4c9a77786fc4c07b258d14aa022ff6903c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cecf06831c0d6dcede596bd4c3e4ab4c9a77786fc4c07b258d14aa022ff6903c->enter($__internal_cecf06831c0d6dcede596bd4c3e4ab4c9a77786fc4c07b258d14aa022ff6903c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_55a44cd34a8bf3851e53d080235b2a75bcffc658cad488cae318482a9d7bb0ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55a44cd34a8bf3851e53d080235b2a75bcffc658cad488cae318482a9d7bb0ab->enter($__internal_55a44cd34a8bf3851e53d080235b2a75bcffc658cad488cae318482a9d7bb0ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_cecf06831c0d6dcede596bd4c3e4ab4c9a77786fc4c07b258d14aa022ff6903c->leave($__internal_cecf06831c0d6dcede596bd4c3e4ab4c9a77786fc4c07b258d14aa022ff6903c_prof);

        
        $__internal_55a44cd34a8bf3851e53d080235b2a75bcffc658cad488cae318482a9d7bb0ab->leave($__internal_55a44cd34a8bf3851e53d080235b2a75bcffc658cad488cae318482a9d7bb0ab_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
