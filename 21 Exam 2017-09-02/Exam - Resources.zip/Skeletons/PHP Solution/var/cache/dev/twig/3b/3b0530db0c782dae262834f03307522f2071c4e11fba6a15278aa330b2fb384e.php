<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_f32ad73c9bc804e7d7685ce925e27ce9c7daa98efc0b9a8c89227d7076a75563 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ca25ef237a5f8311f76f6974035f551bdac6aac215c0241ce40df25f6d67863 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ca25ef237a5f8311f76f6974035f551bdac6aac215c0241ce40df25f6d67863->enter($__internal_9ca25ef237a5f8311f76f6974035f551bdac6aac215c0241ce40df25f6d67863_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_b794d962b3192147262988d2ca69dc99044b046a9c4eb3ff5d92c562bfd6d7e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b794d962b3192147262988d2ca69dc99044b046a9c4eb3ff5d92c562bfd6d7e0->enter($__internal_b794d962b3192147262988d2ca69dc99044b046a9c4eb3ff5d92c562bfd6d7e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9ca25ef237a5f8311f76f6974035f551bdac6aac215c0241ce40df25f6d67863->leave($__internal_9ca25ef237a5f8311f76f6974035f551bdac6aac215c0241ce40df25f6d67863_prof);

        
        $__internal_b794d962b3192147262988d2ca69dc99044b046a9c4eb3ff5d92c562bfd6d7e0->leave($__internal_b794d962b3192147262988d2ca69dc99044b046a9c4eb3ff5d92c562bfd6d7e0_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_a699ce10e5a18c32491ebe0c074a723e15e1c3766215dd217cd8672a7b9184bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a699ce10e5a18c32491ebe0c074a723e15e1c3766215dd217cd8672a7b9184bf->enter($__internal_a699ce10e5a18c32491ebe0c074a723e15e1c3766215dd217cd8672a7b9184bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_dda67281acd288444f568c68cf48d77049f353692a52cd51b3a3bfdc9f8e2322 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dda67281acd288444f568c68cf48d77049f353692a52cd51b3a3bfdc9f8e2322->enter($__internal_dda67281acd288444f568c68cf48d77049f353692a52cd51b3a3bfdc9f8e2322_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_dda67281acd288444f568c68cf48d77049f353692a52cd51b3a3bfdc9f8e2322->leave($__internal_dda67281acd288444f568c68cf48d77049f353692a52cd51b3a3bfdc9f8e2322_prof);

        
        $__internal_a699ce10e5a18c32491ebe0c074a723e15e1c3766215dd217cd8672a7b9184bf->leave($__internal_a699ce10e5a18c32491ebe0c074a723e15e1c3766215dd217cd8672a7b9184bf_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c1cf36df22454ef285b01e389e0521fc1b024706a0116e83c840f44f3e401ae2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c1cf36df22454ef285b01e389e0521fc1b024706a0116e83c840f44f3e401ae2->enter($__internal_c1cf36df22454ef285b01e389e0521fc1b024706a0116e83c840f44f3e401ae2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_b614fb63313833d217ef6e83f0311919e49e961a20de4da2eac695932b55ac6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b614fb63313833d217ef6e83f0311919e49e961a20de4da2eac695932b55ac6b->enter($__internal_b614fb63313833d217ef6e83f0311919e49e961a20de4da2eac695932b55ac6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_b614fb63313833d217ef6e83f0311919e49e961a20de4da2eac695932b55ac6b->leave($__internal_b614fb63313833d217ef6e83f0311919e49e961a20de4da2eac695932b55ac6b_prof);

        
        $__internal_c1cf36df22454ef285b01e389e0521fc1b024706a0116e83c840f44f3e401ae2->leave($__internal_c1cf36df22454ef285b01e389e0521fc1b024706a0116e83c840f44f3e401ae2_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_7f10bee47f2661ea948041b89771df2b34b04f51a7de54876f502a312712c6ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f10bee47f2661ea948041b89771df2b34b04f51a7de54876f502a312712c6ac->enter($__internal_7f10bee47f2661ea948041b89771df2b34b04f51a7de54876f502a312712c6ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_5b5903f28ebf275e302449b8773b490789d13634572cb4962e72817a28fc990e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5b5903f28ebf275e302449b8773b490789d13634572cb4962e72817a28fc990e->enter($__internal_5b5903f28ebf275e302449b8773b490789d13634572cb4962e72817a28fc990e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_5b5903f28ebf275e302449b8773b490789d13634572cb4962e72817a28fc990e->leave($__internal_5b5903f28ebf275e302449b8773b490789d13634572cb4962e72817a28fc990e_prof);

        
        $__internal_7f10bee47f2661ea948041b89771df2b34b04f51a7de54876f502a312712c6ac->leave($__internal_7f10bee47f2661ea948041b89771df2b34b04f51a7de54876f502a312712c6ac_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
