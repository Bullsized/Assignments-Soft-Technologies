<?php

/* product/index.html.twig */
class __TwigTemplate_51ac92d81a5edb2787f53f7369354f0b4f3b17b6549195ffe854d8515f5a0e67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "product/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3b4b0cc53833dc9f64ffc61a55ed514ea00306305c334acb3bc4eb59e6e1e329 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3b4b0cc53833dc9f64ffc61a55ed514ea00306305c334acb3bc4eb59e6e1e329->enter($__internal_3b4b0cc53833dc9f64ffc61a55ed514ea00306305c334acb3bc4eb59e6e1e329_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/index.html.twig"));

        $__internal_4eee14058d1a358d640cbb0d2caf9ba8dde01f69c02ce0e0857481d333be0f09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4eee14058d1a358d640cbb0d2caf9ba8dde01f69c02ce0e0857481d333be0f09->enter($__internal_4eee14058d1a358d640cbb0d2caf9ba8dde01f69c02ce0e0857481d333be0f09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "product/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3b4b0cc53833dc9f64ffc61a55ed514ea00306305c334acb3bc4eb59e6e1e329->leave($__internal_3b4b0cc53833dc9f64ffc61a55ed514ea00306305c334acb3bc4eb59e6e1e329_prof);

        
        $__internal_4eee14058d1a358d640cbb0d2caf9ba8dde01f69c02ce0e0857481d333be0f09->leave($__internal_4eee14058d1a358d640cbb0d2caf9ba8dde01f69c02ce0e0857481d333be0f09_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_930354f4c70a06e9e7aeba1876771a3dc274c54d506dc417ba2f31c7cff67ead = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_930354f4c70a06e9e7aeba1876771a3dc274c54d506dc417ba2f31c7cff67ead->enter($__internal_930354f4c70a06e9e7aeba1876771a3dc274c54d506dc417ba2f31c7cff67ead_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_f7c7c50b7c10a1b1ef05805b9158dc42a637a79676830e10571ecb91ea5c8b9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7c7c50b7c10a1b1ef05805b9158dc42a637a79676830e10571ecb91ea5c8b9e->enter($__internal_f7c7c50b7c10a1b1ef05805b9158dc42a637a79676830e10571ecb91ea5c8b9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<h1>Shopping List</h1>

<section>
    <div>
        <table>
            <tr>
                <th>Priority</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["product"]) {
            // line 17
            echo "            <tr>
                <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "priority", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "quantity", array()), "html", null, true);
            echo "</td>
                <td>
                    <input class=\"checkbox\" type=\"checkbox\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "status", array()), "html", null, true);
            echo "\" onclick=\"preventEvent(event)\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "name", array()), "html", null, true);
            echo "\" />
                    <label for=\"";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "name", array()), "html", null, true);
            echo "\"></label>
                </td>
                <td>
                    <button class=\"edit\" onclick=\"location.href='/edit/";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["product"], "id", array()), "html", null, true);
            echo "'\">Edit</button>
                </td>
            </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['product'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 30
        echo "        </table>
    </div>
</section>

<div>
    <button class=\"add-new\" onclick=\"location.href='/create'\">+</button>
</div>

<script>
    function preventEvent(ev) {
        ev.preventDefault();
    }
    (function checkBox() {
        let checkboxes = document.getElementsByClassName(\"checkbox\");

        for(let i = 0; i < checkboxes.length; i++) {
            if(checkboxes[i].value === \"bought\") {
                checkboxes[i].checked = true;
            }
        }
    })();
</script>
";
        
        $__internal_f7c7c50b7c10a1b1ef05805b9158dc42a637a79676830e10571ecb91ea5c8b9e->leave($__internal_f7c7c50b7c10a1b1ef05805b9158dc42a637a79676830e10571ecb91ea5c8b9e_prof);

        
        $__internal_930354f4c70a06e9e7aeba1876771a3dc274c54d506dc417ba2f31c7cff67ead->leave($__internal_930354f4c70a06e9e7aeba1876771a3dc274c54d506dc417ba2f31c7cff67ead_prof);

    }

    public function getTemplateName()
    {
        return "product/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 30,  95 => 26,  89 => 23,  83 => 22,  78 => 20,  74 => 19,  70 => 18,  67 => 17,  63 => 16,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<h1>Shopping List</h1>

<section>
    <div>
        <table>
            <tr>
                <th>Priority</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            {% for product in products %}
            <tr>
                <td>{{ product.priority }}</td>
                <td>{{ product.name }}</td>
                <td>{{ product.quantity }}</td>
                <td>
                    <input class=\"checkbox\" type=\"checkbox\" value=\"{{ product.status }}\" onclick=\"preventEvent(event)\" name=\"{{ product.name }}\" />
                    <label for=\"{{ product.name }}\"></label>
                </td>
                <td>
                    <button class=\"edit\" onclick=\"location.href='/edit/{{ product.id }}'\">Edit</button>
                </td>
            </tr>
            {% endfor %}
        </table>
    </div>
</section>

<div>
    <button class=\"add-new\" onclick=\"location.href='/create'\">+</button>
</div>

<script>
    function preventEvent(ev) {
        ev.preventDefault();
    }
    (function checkBox() {
        let checkboxes = document.getElementsByClassName(\"checkbox\");

        for(let i = 0; i < checkboxes.length; i++) {
            if(checkboxes[i].value === \"bought\") {
                checkboxes[i].checked = true;
            }
        }
    })();
</script>
{% endblock %}", "product/index.html.twig", "F:\\00. Work\\Software-Technologies-Exam-02-09-2017\\PHP Skeleton\\app\\Resources\\views\\product\\index.html.twig");
    }
}
