package shoppinglist.bindingModel;

public class ProductBindingModel {
	//TODO: Implement me ...
}
